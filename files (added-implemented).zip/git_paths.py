"""Derive a merged PR's net changed paths WITHOUT the REST API, using only git over github.com (commit objects only; no file contents).
Method (documented deviation from the frozen protocol, which specified the pulls/files API):
  head = refs/pull/N/head ; tip = default branch history since (PR created_at - 14 days)
  * head reachable from tip (merge-commit merge): find merge commit M with second parent == head ; paths = diff(M^1...M^2)
  * otherwise (squash / rebase merge): mb = merge-base(head, tip) ; paths = diff(mb, head)
  diff uses --no-renames so both old and new paths of a rename are listed (as the protocol's filename + previous_filename)."""
import os, subprocess, tempfile, shutil, datetime, json, sys
def run(cmd, cwd, timeout=120):
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout.strip(), p.stderr.strip()
def paths_for(repo, number, created_at):
    d = tempfile.mkdtemp(prefix="pr_")
    info = {"method": None, "error": None}
    try:
        run(["git", "init", "-q"], d); run(["git", "remote", "add", "origin", f"https://github.com/{repo}.git"], d)
        since = (datetime.datetime.fromisoformat(created_at.replace("Z", "+00:00")) - datetime.timedelta(days=14)).strftime("%Y-%m-%d")
        rc, _, err = run(["git", "fetch", "-q", "--filter=tree:0", "--depth=300", "origin", f"refs/pull/{number}/head:refs/pr/head"], d, 180)
        if rc: info["error"] = "fetch head: " + err[:150]; return info, []
        rc, _, err = run(["git", "fetch", "-q", "--filter=tree:0", f"--shallow-since={since}", "origin", "HEAD:refs/pr/tip"], d, 180)
        if rc: info["error"] = "fetch tip: " + err[:150]; return info, []
        head = run(["git", "rev-parse", "refs/pr/head"], d)[1]
        anc = run(["git", "merge-base", "--is-ancestor", "refs/pr/head", "refs/pr/tip"], d)[0] == 0
        if anc:
            rc, out, _ = run(["git", "rev-list", "--parents", "--merges", "refs/pr/tip"], d)
            M = None
            for line in out.splitlines():
                parts = line.split()
                if len(parts) >= 3 and parts[2] == head: M = parts[0]; break
            if not M: info["error"] = "head reachable from tip but no merge commit with it as 2nd parent (fast-forward?)"; return info, []
            rc, out, err = run(["git", "diff", "--no-renames", "--name-only", f"{M}^1...{M}^2"], d)
            info["method"] = "merge_commit"
        else:
            rc, mb, err = run(["git", "merge-base", "refs/pr/head", "refs/pr/tip"], d)
            if rc or not mb: info["error"] = "no merge-base in fetched history"; return info, []
            rc, out, err = run(["git", "diff", "--no-renames", "--name-only", mb, "refs/pr/head"], d, 180)
            info["method"] = "merge_base"; info["merge_base"] = mb
        if rc: info["error"] = "diff: " + err[:150]; return info, []
        paths = [l for l in out.splitlines() if l]
        # independent validation: a squash-merged PR lands as ONE commit on the default branch whose subject ends with "(#N)"
        info["validation"] = "n/a"
        rc2, lg, _ = run(["git", "log", "--format=%H%x09%P%x09%s", "refs/pr/tip"], d)
        land = [l.split("\t") for l in lg.splitlines() if l.split("\t")[-1].rstrip().endswith(f"(#{number})")]
        land = [x for x in land if len(x[1].split()) == 1]
        if len(land) == 1:
            rc3, o3, _ = run(["git", "diff", "--no-renames", "--name-only", f"{land[0][0]}^", land[0][0]], d)
            if rc3 == 0:
                info["validation"] = "agree" if set(l for l in o3.splitlines() if l) == set(paths) else "disagree"
                if info["validation"] == "disagree": info["landing_paths"] = [l for l in o3.splitlines() if l][:30]
        return info, paths
    except subprocess.TimeoutExpired:
        info["error"] = "timeout"; return info, []
    finally:
        shutil.rmtree(d, ignore_errors=True)
if __name__ == "__main__":
    import time; t = time.time()
    info, paths = paths_for(sys.argv[1], int(sys.argv[2]), sys.argv[3])
    print(info, len(paths), "paths", f"{time.time()-t:.1f}s"); print("\n".join(paths[:15]))
