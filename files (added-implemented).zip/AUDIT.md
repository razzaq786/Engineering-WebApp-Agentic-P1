# Manual audit of every flagged PR (frozen rules; files opened at the PR head commit)
| PR | Flagged path | Verdict |
|---|---|---|
| hahaxiaowai/hahaxiaowai#4 | .github/workflows/generate-snake.yml | true hit: scheduled Actions workflow (profile graphic), requests contents: write |
| CorbinVentures/HiFi-Stream-OS#1 | .github/workflows/android-ci.yml, security.yml | true hits: build/test and secret-scan CI workflows |
| victorscatolon/victorscatolon#2 | .github/workflows/profile-3d.yml | true hit: scheduled Actions workflow (profile graphic) |
| microsoft/aspire#19939 | .github/actions/check-changed-files/action.yml | true hit: composite action used by CI |
| bcit-tlu/hriv#896 | .github/workflows/ci.yaml | true hit: test, build and publish pipeline |
| IntusCare/Intus-skills#2 | .github/workflows/bump-version.yml | true hit: push workflow that commits back to main, requests contents: write |
False positives: 0 of 6. Credential-file hits: 0.
