# Real-data replay on public agent-authored pull requests (complete)

Frozen before data collection: PROTOCOL.md, protocol_rules.py (hashes in protocol.sha256); the 60-PR sample
(part_b_sample.jsonl, hash in sample.sha256).

## Contents
- Part A (population counts of merged agent PRs by review state): part_a.py, part_a_counts.csv
- Sampling (seeded): sample.py -> part_b_sample.jsonl
- Part B changed paths, METHOD USED: git over github.com, commit objects only: git_paths.py, part_b_files_git.py -> part_b_files_git.jsonl
  (deviation from the frozen protocol, which specified the REST API; forced by rate limits in the research environment;
   validated against the squash landing commit where one exists, see paper section)
- Part B analysis (frozen rules): part_b_analyze.py -> part_b_results_git.csv, part_b_summary_git.json
- Manual audit of every flagged PR: AUDIT.md
- Optional confirmation with the originally specified API method: part_b_files.py (+ part_b_analyze.py part_b_files.jsonl)
- Tests: test_rules.py

## Reproduce (Python 3 + requests + git)
    python test_rules.py
    python part_b_files_git.py 300          # about 1-2 minutes, resumable
    python part_b_analyze.py part_b_files_git.jsonl _git
Optional API confirmation (no token: 60 requests/hour; with a no-scope token in GITHUB_TOKEN: instant):
    python part_b_files.py --wait
    python part_b_analyze.py part_b_files.jsonl
Counts in part_a_counts.csv are live GitHub search counts taken on 18 Nov 2026 and will drift.
