"""Git-based fetch of changed paths for the frozen 60-PR sample (no REST API). Resumable.  python part_b_files_git.py [max_seconds]"""
import json, os, sys, time, datetime
from git_paths import paths_for
SAMPLE, OUT = "part_b_sample.jsonl", "part_b_files_git.jsonl"
done = {(d["repo"], d["number"]) for d in map(json.loads, open(OUT))} if os.path.exists(OUT) else set()
budget = float(sys.argv[1]) if len(sys.argv) > 1 else 140
t0 = time.time(); n = 0
with open(OUT, "a") as f:
    for l in open(SAMPLE):
        s = json.loads(l)
        if (s["repo"], s["number"]) in done: continue
        if time.time() - t0 > budget: break
        info, paths = paths_for(s["repo"], s["number"], s["created_at"])
        rec = {"agent": s["agent"], "stratum": s["stratum"], "repo": s["repo"], "number": s["number"], "error": info.get("error"),
               "method": info.get("method"), "validation": info.get("validation"), "landing_paths": info.get("landing_paths"),
               "n_files_first_page": len(paths), "possibly_truncated": False,
               "files": [{"filename": p, "previous_filename": None, "status": "touched"} for p in paths],
               "fetched_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")}
        f.write(json.dumps(rec) + "\n"); f.flush(); n += 1
        print(f"{n:3d} {s['repo']}#{s['number']} {rec['method']} files={len(paths)} val={rec['validation']} {rec['error'] or ''}", flush=True)
print("total done:", len(done) + n, "of 60")
