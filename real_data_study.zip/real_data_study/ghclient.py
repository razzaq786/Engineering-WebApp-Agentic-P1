import time, json, requests
H = {"User-Agent": "awa-control-plane-replay/1.0", "Accept": "application/vnd.github+json"}
def search_issues(q, per_page=1, page=1, sort=None, order=None, min_gap=7.0):
    """Search API call with rate-limit handling (unauthenticated: 10 requests/min)."""
    params = {"q": q, "per_page": per_page, "page": page}
    if sort: params["sort"] = sort
    if order: params["order"] = order
    for attempt in range(6):
        r = requests.get("https://api.github.com/search/issues", headers=H, params=params, timeout=40)
        if r.status_code == 200:
            time.sleep(min_gap); return r.json()
        if r.status_code in (403, 429):
            wait = int(r.headers.get("Retry-After", 0)) or max(5, int(r.headers.get("x-ratelimit-reset", 0)) - int(time.time()) + 2)
            time.sleep(min(wait, 70)); continue
        if r.status_code == 422:
            return {"error": 422, "message": r.text[:200]}
        time.sleep(5)
    return {"error": r.status_code, "message": r.text[:200]}
