# Real-data replay on public agent-authored pull requests

Frozen before data collection: PROTOCOL.md, protocol_rules.py (hashes in protocol.sha256). The 60-PR sample is frozen
too (part_b_sample.jsonl; hash in sample.sha256). Part A (population counts) is already collected: part_a_counts.csv.

## What is left: fetch changed-file paths for the 60 sampled PRs (needs your machine)
The sandbox could not do this (shared GitHub API budget, patch-diff host blocked).

Windows PowerShell, in this folder:
    python -m venv .venv
    .venv\Scripts\Activate.ps1
    pip install requests
    python test_rules.py                      # expect: ALL TESTS PASSED
    Get-FileHash part_b_sample.jsonl -Algorithm SHA256   # must equal the value in sample.sha256

Create a GitHub token with NO scopes (Settings > Developer settings > Personal access tokens > Tokens (classic),
leave every scope unticked, expiry 7 days). It can only read public data. Do NOT paste it into any chat.
    $env:GITHUB_TOKEN = "<your token>"
    python part_b_files.py                    # 60 requests, about 1 minute
    python part_b_analyze.py                  # writes part_b_results.csv and part_b_summary.json, lists flagged PRs

Without a token, unauthenticated GitHub allows 60 requests/hour, which is exactly the 60 needed:
    python part_b_files.py --wait             # resumable; sleeps through the rate limit

Send back: part_b_files.jsonl, part_b_results.csv, part_b_summary.json. Revoke the token afterwards.
Requirements: Python 3 and `requests` only.
