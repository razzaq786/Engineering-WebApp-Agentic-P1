"""
Pre-specified policy rules for the real-data replay (frozen BEFORE data collection).
They operationalize ONLY what Section 4.3 of the manuscript states: schema/tool validation
rejects a patch that "modifies disallowed paths such as CI/CD configuration or deployment
credentials". No other rule is applied. Rules are not tuned on the data.
"""
import re

CI_CD_PATTERNS = [
    r'^\.github/workflows/', r'^\.github/actions/',
    r'^\.gitlab-ci\.ya?ml$', r'^\.gitlab/ci/',
    r'(^|/)Jenkinsfile$', r'^\.circleci/',
    r'(^|/)azure-pipelines[^/]*\.ya?ml$', r'^\.azure-pipelines/',
    r'^\.travis\.ya?ml$', r'^bitbucket-pipelines\.ya?ml$',
    r'^\.drone\.ya?ml$', r'^\.buildkite/',
]
CREDENTIAL_PATTERNS = [
    r'(^|/)\.env(\.(?!example$|sample$|template$|dist$)[^/]+)?$',
    r'\.(pem|p12|pfx|jks|keystore)$',
    r'(^|/)id_(rsa|dsa|ecdsa|ed25519)$',
    r'(^|/)(credentials|secrets?)([._-][^/]*)?\.(json|ya?ml|toml|ini)$',
    r'(^|/)service[-_]?account[^/]*\.json$',
    r'\.tfvars$', r'(^|/)\.aws/credentials$',
]
_ci = [re.compile(p, re.I) for p in CI_CD_PATTERNS]
_cr = [re.compile(p, re.I) for p in CREDENTIAL_PATTERNS]

def classify_path(path: str):
    """Return a set of violation labels for one changed file path."""
    out = set()
    if any(r.search(path) for r in _ci): out.add('ci_cd')
    if any(r.search(path) for r in _cr): out.add('credentials')
    return out

def classify_pr(paths):
    """Replay of the Section 4.3 scope check over a PR's changed paths."""
    labels = set()
    for p in paths: labels |= classify_path(p)
    return ('DISALLOWED_PATH' if labels else 'IN_SCOPE'), sorted(labels)
