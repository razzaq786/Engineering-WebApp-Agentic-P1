import json, csv, collections
from protocol_rules import classify_pr
from analysis_lib import wilson
sample = {(d["repo"], d["number"]): d for d in map(json.loads, open("part_b_sample.jsonl"))}
files = [json.loads(l) for l in open("part_b_files.jsonl")]
rows, errors = [], []
for r in files:
    s = sample[(r["repo"], r["number"])]
    if r["error"]: errors.append((r["repo"], r["number"], r["error"])); continue
    paths = []
    for f in r["files"]:
        paths += [p for p in (f["filename"], f["previous_filename"]) if p]
    outcome, labels = classify_pr(paths)
    from protocol_rules import classify_path
    flagged = sorted({p for p in paths if classify_path(p)})
    rows.append({"agent": r["agent"], "stratum": r["stratum"], "repo": r["repo"], "number": r["number"], "url": s["html_url"],
                 "n_files": r["n_files_first_page"], "possibly_truncated": r["possibly_truncated"], "outcome": outcome,
                 "labels": "+".join(labels), "flagged_paths": " | ".join(flagged)})
with open("part_b_results.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
def cell(sel):
    sub = [x for x in rows if sel(x)]; n = len(sub); k = sum(x["outcome"] == "DISALLOWED_PATH" for x in sub)
    ci = sum("ci_cd" in x["labels"] for x in sub); cr = sum("credentials" in x["labels"] for x in sub)
    lo, hi = wilson(k, n); return {"n": n, "disallowed": k, "ci_cd": ci, "credentials": cr, "wilson95": [round(lo,3), round(hi,3)]}
summary = {"fetched": len(files), "errors": errors, "analysed": len(rows), "by_cell": {}, "by_stratum": {}, "by_agent": {}, "overall": cell(lambda x: True)}
for a in sorted({x["agent"] for x in rows}):
    summary["by_agent"][a] = cell(lambda x, a=a: x["agent"] == a)
    for st in ("none", "approved"):
        summary["by_cell"][f"{a}|{st}"] = cell(lambda x, a=a, st=st: x["agent"] == a and x["stratum"] == st)
for st in ("none", "approved"): summary["by_stratum"][st] = cell(lambda x, st=st: x["stratum"] == st)
json.dump(summary, open("part_b_summary.json", "w"), indent=2)
print(json.dumps(summary, indent=2))
print("\n--- ALL FLAGGED PRs (manual false-positive audit list) ---")
for x in rows:
    if x["outcome"] != "IN_SCOPE": print(x["agent"], x["stratum"], x["url"], x["labels"], "::", x["flagged_paths"][:200])
