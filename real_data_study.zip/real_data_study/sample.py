import json, os, sys, random, datetime, hashlib
from ghclient import search_issues
START = datetime.datetime(2026,5,22,0,0,0, tzinfo=datetime.timezone.utc)
END   = datetime.datetime(2026,11,10,23,0,0, tzinfo=datetime.timezone.utc)
HOURS = int((END-START).total_seconds()//3600)
N_PER_CELL = 10
OUT = "part_b_sample.jsonl"
done = set()
if os.path.exists(OUT):
    for l in open(OUT): d=json.loads(l); done.add((d["agent"], d["stratum"], d["slot"]))
def draw(agent, stratum, slot, max_budget):
    for redraw in range(25):
        if max_budget[0] <= 0: return "BUDGET"
        rng = random.Random(f"20261118|{agent}|{stratum}|{slot}|{redraw}")
        s = START + datetime.timedelta(hours=rng.randrange(HOURS)); e = s + datetime.timedelta(minutes=59, seconds=59)
        win = f"{s:%Y-%m-%dT%H:%M:%SZ}..{e:%Y-%m-%dT%H:%M:%SZ}"
        q = f"is:pr is:merged author:app/{agent} review:{stratum} created:{win}"
        max_budget[0] -= 1
        d = search_issues(q, per_page=100, sort="created", order="asc")
        items = d.get("items") or []
        if items:
            it = random.Random(f"20261118|{agent}|{stratum}|{slot}|{redraw}|pick").choice(items)
            return {"agent": agent, "stratum": stratum, "slot": slot, "redraws": redraw, "window": win,
                    "window_result_count": len(items), "window_total_count": d.get("total_count"),
                    "repo": it["repository_url"].replace("https://api.github.com/repos/",""),
                    "number": it["number"], "html_url": it["html_url"], "created_at": it["created_at"],
                    "merged_at": (it.get("pull_request") or {}).get("merged_at")}
    return None
if __name__ == "__main__":
    agent, stratum = sys.argv[1], sys.argv[2]; budget=[int(sys.argv[3])]
    with open(OUT, "a") as f:
        for slot in range(N_PER_CELL):
            if (agent, stratum, slot) in done: continue
            r = draw(agent, stratum, slot, budget)
            if r == "BUDGET" or r is None: print("stopped at slot", slot, r); break
            f.write(json.dumps(r)+"\n"); f.flush(); print(agent, stratum, slot, r["repo"], r["number"], "redraws", r["redraws"], flush=True)
