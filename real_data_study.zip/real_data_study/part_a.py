import csv, json, sys, os, datetime
from ghclient import search_issues
SPECS = [("all_prs", ""), ("merged", " is:merged"), ("merged_review_none", " is:merged review:none"),
         ("merged_review_approved", " is:merged review:approved"), ("merged_review_changes_requested", " is:merged review:changes_requested")]
new = not os.path.exists("part_a_counts.csv")
with open("part_a_counts.csv", "a", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["agent","measure","query","total_count","incomplete_results","error","collected_utc"])
    if new: w.writeheader()
    for a in sys.argv[1:]:
        for name, extra in SPECS:
            q = f"is:pr author:app/{a}{extra}"
            d = search_issues(q, per_page=1)
            row = {"agent": a, "measure": name, "query": q, "total_count": d.get("total_count"),
                   "incomplete_results": d.get("incomplete_results"), "error": d.get("error"),
                   "collected_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")}
            w.writerow(row); f.flush()
            print(a, name, row["total_count"], row["incomplete_results"], row["error"], flush=True)
