# Pre-specified protocol: replay of the manuscript's controls on real, public agent-authored pull requests
Frozen before any data collection. Date (UTC): 2026-11-18.

Question. On real public agent-authored PRs, how often would (A) the approval gate and (B) the Section 4.3 path-scope
check have been relevant? This is a COVERAGE/TRIGGER-RATE study, not an effectiveness or harm study.

Data. GitHub REST API, public data only (search API for PRs; pulls/files API for changed paths).
Agents (identified by their GitHub App bot author): copilot-swe-agent, devin-ai-integration, google-labs-jules.
Inclusion rule: an agent is analysed only if it has >= 200 merged PRs at collection time.

Part A (population counts, whole public GitHub, as of collection date), per agent:
  merged PRs; merged with review:none; merged with review:approved; remainder = other review states.
  Reported as raw counts and shares. "review:none" = no review recorded (a merge click is still a human act).

Part B (sample replay of Section 4.3 rules):
  Per included agent, up to 10 merged PRs with review:none and 10 merged with review:approved.
  Sampling: seeded (20261118) uniformly random 1-hour created-windows in [2026-05-22, 2026-11-10]; one
  uniformly random PR from the first result page of each window; redraw a window only if it returns zero PRs.
  Changed paths: first 100 files of the PR. Rules: protocol_rules.py (frozen). Outcome per PR: IN_SCOPE or
  DISALLOWED_PATH (labels ci_cd / credentials). Wilson 95% intervals. All rule hits are manually audited for false positives.

Not claimed: that any flagged PR was harmful; that agents behave differently from humans; generalisation beyond bot-authored
PRs of these agents; any effect of the architecture on agent behaviour.
