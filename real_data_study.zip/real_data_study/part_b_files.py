"""Fetch the changed-file paths of the frozen 60-PR sample (GitHub REST: GET /repos/{repo}/pulls/{n}/files).
Resumable. Optional: export GITHUB_TOKEN=<token with NO scopes> for 5000 requests/hour (unauthenticated = 60/hour).
Usage: python part_b_files.py            (stops cleanly when the rate limit is reached; re-run later to resume)
       python part_b_files.py --wait     (sleeps until the limit resets and continues)"""
import json, os, sys, time, datetime, requests
H = {"User-Agent": "awa-control-plane-replay/1.0", "Accept": "application/vnd.github+json"}
if os.environ.get("GITHUB_TOKEN"): H["Authorization"] = "Bearer " + os.environ["GITHUB_TOKEN"]
SAMPLE, OUT = "part_b_sample.jsonl", "part_b_files.jsonl"
done = {(d["repo"], d["number"]) for d in map(json.loads, open(OUT))} if os.path.exists(OUT) else set()
wait = "--wait" in sys.argv
sample = [json.loads(l) for l in open(SAMPLE)]
n_new = 0
with open(OUT, "a") as f:
    for s in sample:
        key = (s["repo"], s["number"])
        if key in done: continue
        url = f"https://api.github.com/repos/{s['repo']}/pulls/{s['number']}/files"
        files, err, page = [], None, 1
        while True:
            r = requests.get(url, headers=H, params={"per_page": 100, "page": page}, timeout=40)
            if r.status_code == 403 and r.headers.get("x-ratelimit-remaining") == "0":
                reset = int(r.headers.get("x-ratelimit-reset", 0)) - int(time.time())
                if wait: print(f"rate limit; sleeping {reset+3}s", flush=True); time.sleep(max(reset+3, 5)); continue
                print(f"RATE LIMITED (resets in {reset}s). Fetched {n_new} this run. Re-run later to resume."); sys.exit(0)
            if r.status_code != 200: err = f"HTTP {r.status_code}"; break
            batch = r.json(); files += batch
            # protocol: first 100 files only
            break
        rec = {"agent": s["agent"], "stratum": s["stratum"], "repo": s["repo"], "number": s["number"], "error": err,
               "n_files_first_page": len(files), "possibly_truncated": len(files) >= 100,
               "files": [{"filename": x.get("filename"), "previous_filename": x.get("previous_filename"), "status": x.get("status")} for x in files],
               "fetched_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")}
        f.write(json.dumps(rec) + "\n"); f.flush(); n_new += 1
        print(f"{n_new:3d} {s['repo']}#{s['number']} files={len(files)} {err or ''}", flush=True)
print("DONE; total fetched:", len(done) + n_new)
