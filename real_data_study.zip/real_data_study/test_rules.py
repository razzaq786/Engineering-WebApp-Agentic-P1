from protocol_rules import classify_path, classify_pr
from analysis_lib import wilson
cases = {
 ".github/workflows/ci.yml": {"ci_cd"}, ".github/actions/setup/action.yml": {"ci_cd"}, ".gitlab-ci.yml": {"ci_cd"},
 "Jenkinsfile": {"ci_cd"}, "services/api/Jenkinsfile": {"ci_cd"}, ".circleci/config.yml": {"ci_cd"}, "azure-pipelines.yml": {"ci_cd"},
 "src/github/workflows.py": set(), "docs/ci.md": set(), "README.md": set(),
 ".env": {"credentials"}, "app/.env.production": {"credentials"}, ".env.example": set(), ".env.sample": set(), "src/env.py": set(),
 "config/secrets.yaml": {"credentials"}, "credentials.json": {"credentials"}, "docs/secrets.md": set(),
 "certs/server.pem": {"credentials"}, "keys/id_rsa": {"credentials"}, "keys/id_rsa.pub": set(), "infra/prod.tfvars": {"credentials"},
 "service-account-prod.json": {"credentials"}, "src/main.py": set(),
}
bad = [(p, classify_path(p), exp) for p, exp in cases.items() if classify_path(p) != exp]
assert not bad, bad
assert classify_pr(["a.py", ".github/workflows/x.yml"]) == ("DISALLOWED_PATH", ["ci_cd"])
assert classify_pr(["a.py", "b.md"]) == ("IN_SCOPE", [])
lo, hi = wilson(0, 10); assert abs(lo) < 1e-9 and abs(hi - 0.2775) < 1e-3, (lo, hi)
lo, hi = wilson(5, 10); assert abs(lo - 0.2366) < 1e-3 and abs(hi - 0.7634) < 1e-3, (lo, hi)
print("ALL TESTS PASSED:", len(cases), "path cases + PR-level + Wilson checks")
