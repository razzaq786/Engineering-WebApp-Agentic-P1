# Reviewer-response implementation matrix

| Reviewer concern | Revision implemented | Evidence/artifact |
|---|---|---|
| No LLM in evaluation | Separate deterministic control-plane study from an executable model-dependent LLM harness; no fabricated LLM results | `llm_runner.py`, Sec. Model-Dependent Evaluation Protocol |
| Tautological four-task pilot | 120 cases across six classes with independent benchmark oracle | `app.py`, `experiment.py`, `results/` |
| Thin evidence synthesis | Expanded bibliography and practitioner landscape; explicit non-claim of exhaustive systematic review | `references.bib`, Sec. 2–3 |
| Missing MCP/framework comparison | Added comparison with MCP, LangGraph, CrewAI, Microsoft Agent Framework, Semantic Kernel, NeMo Guardrails | Table practitioner landscape |
| Formalism descriptive | Added model non-authority proposition and proof sketch; provenance/taint rule | Sec. Formal Control Model, Context and Memory |
| Small sample/statistical claims | 120-case deterministic benchmark; descriptive proportions; no population claims | Sec. Metrics/Validity |
| RQs not closed | Added explicit RQ closure subsection | Sec. Answers to RQs |
| ASCII architecture | Replaced with rendered TikZ architecture figure with trust boundaries | Figure 1 |
| Control-plane overhead | Added latency measurement and risk-adaptive control discussion | Results + Discussion |
| Human approval unspecified | Added explicit approval state machine, action-bound approvals and expiry semantics | Figure 2 |
| Memory poisoning | Added provenance, trust/taint, expiry and no-trust-upgrade rule | Context and Memory |
| Running example | Added travel booking scenario and threaded its engineering implications | Running Example subsection |
