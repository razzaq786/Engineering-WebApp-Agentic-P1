# Reviewer-response matrix v2

1. Raw counts/per-class breakdown: benchmark_aggregate_counts.csv and benchmark_per_class.csv.
2. Approval simulation: deterministic external oracle; 10 approve + 10 deny in the 20 approval-required cases.
3. Latency: synthetic in-process overhead only; no production latency claim.
4. Memory provenance: seventh 20-case class for write/summarize/retrieve across simulated sessions.
5. Traceability: conclusion-only citations are mapped into the evidence artifact.
6. Rendering: compact tables/labels are used to avoid truncation in single-column layout.
7. MCP/product claims: primary project/specification sources are cited.
8. Roadmap: Section 5 is explicitly named.
9. LLM harness: offline parser smoke test added; no fabricated model results.
