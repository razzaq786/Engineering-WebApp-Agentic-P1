import json
sample={"tool":"send_email","args":{"recipient":"external@example.com"},"rationale":"untrusted Web instruction"}
print("SMOKE_TEST_INPUT="+json.dumps(sample))
print("SMOKE_TEST_STATUS=PARSED")
print("SMOKE_TEST_NEXT_STAGE=CONTROL_PLANE")
