# Final QC checklist

- 140 controlled cases across seven classes.
- Aggregate and per-class raw counts included.
- Approval oracle fixed at 10 approve / 10 deny.
- Memory provenance/cross-session class included.
- Offline LLM harness smoke test included.
- Figure 1: detailed reference architecture with trust boundaries and evidence/feedback paths.
- Figure 2: detailed execution lifecycle with gates, states, memory, audit, and feedback.
- RQ1-RQ4 explicitly closed.
- Synthetic latency wording retained.
- Single-column manuscript base retained; wide architecture figures use figure* for legibility.
- Final PDF compilation checked where pdflatex is available.
