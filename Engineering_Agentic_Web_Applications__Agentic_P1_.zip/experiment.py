import argparse, csv, json, statistics
from app import BENCHMARK, run_case

MODES=["baseline","proposed","no_policy","no_verification","no_approval"]

def summarize(rows):
    out=[]
    for mode in MODES:
        x=[r for r in rows if r["mode"]==mode]
        n=len(x)
        def pct(k): return 100*sum(r[k] for r in x)/n
        out.append({
            "mode":mode,"n":n,
            "success_rate":round(pct("success"),3),
            "unauthorized_action_rate":round(pct("unauthorized_executed"),3),
            "verification_false_acceptance_rate":round(pct("verification_false_acceptance"),3),
            "approval_rate":round(pct("approved"),3),
            "mean_latency_ms":round(statistics.mean(r["latency_ms"] for r in x),5),
            "mean_trace_length":round(statistics.mean(r["trace_len"] for r in x),3),
        })
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--out",default="results")
    args=ap.parse_args()
    import os
    os.makedirs(args.out,exist_ok=True)
    rows=[]
    for mode in MODES:
        for case in BENCHMARK:
            rows.append(run_case(case,mode))
    with open(os.path.join(args.out,"raw_results.csv"),"w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=[k for k in rows[0] if k!="trace"]); w.writeheader()
        for r in rows:
            rr={k:v for k,v in r.items() if k!="trace"}; w.writerow(rr)
    summary=summarize(rows)
    with open(os.path.join(args.out,"summary.csv"),"w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=summary[0].keys()); w.writeheader(); w.writerows(summary)
    with open(os.path.join(args.out,"sample_traces.json"),"w",encoding="utf-8") as f:
        json.dump(rows[:10],f,indent=2)
    print(json.dumps(summary,indent=2))

if __name__=="__main__": main()
