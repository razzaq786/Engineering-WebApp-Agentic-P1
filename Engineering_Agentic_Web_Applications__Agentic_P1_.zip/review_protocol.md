# Evidence synthesis protocol

Scope: Agentic Web applications, LLM/Web agents, tool use, Web-agent evaluation, memory, and security.

Search concepts:
1. ("LLM agent" OR "AI agent" OR agentic) AND (Web OR browser OR "Web application")
2. ("Web agent" OR "browser agent") AND (evaluation OR benchmark OR architecture)
3. ("LLM agent" OR "Web agent") AND ("prompt injection" OR security OR authorization)
4. ("LLM agent" OR "AI agent") AND (memory OR planning OR tool use)

Inclusion:
- Peer-reviewed paper, established technical preprint, or authoritative security guidance.
- Directly relevant to agent architecture, Web interaction, evaluation, memory, or security.
- Provides a technical method, benchmark, design principle, or empirical finding.

Exclusion:
- Pure chatbot work without delegated action.
- Opinion/news without technical evidence.
- Product announcements without reproducible technical detail.
- Unrelated application domains.

Extraction fields:
problem, agent capability, environment, action surface, tool boundary, memory, evaluation, security concern, engineering implication.

The manuscript explicitly treats this as a structured evidence synthesis rather than claiming an exhaustive systematic review. A final journal submission should add database-specific queries, screening counts, quality assessment, and a PRISMA-style flow.
